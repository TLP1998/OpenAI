package com.tlp1998.xiaodi.shadowprobe

import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** On-device only; no lat/lon, vehicle ID, Bluetooth address, PIN, account or raw messages. */
data class DiagnosticRow(
    val elapsedMs: Long,
    val session: Int,
    val event: String,
    val targetSelected: Boolean,
    val serviceAdvertised: Boolean,
    val rawRssi: Int?,
    val gpsEnabled: Boolean,
    val zone: String,
    val gpsAccuracyMeters: Double?,
    val gpsAgeMs: Long?,
    val parkedAgeMs: Long?,
    val thresholdDbm: Int?,
    val decision: String,
    val reason: String,
    val scannerHealthy: Boolean,
    val boundSeenAgeMs: Long? = null,
    val annotation: String = ""
)

class DiagnosticCsvRecorder(private val file: File) {
    companion object {
        const val MAX_RECORDS = 30000
        const val HEADER = "utc_iso,elapsed_ms,session,event,target_selected,service_advertised,raw_rssi_dbm,gps_opt_in,gps_zone,gps_accuracy_m,gps_age_ms,parking_age_ms,threshold_dbm,decision,reason,scanner_healthy,bound_last_seen_age_ms,gate_context,command_sent,annotation"
        fun cell(value: Any?): String {
            val str = (value?.toString() ?: "").take(160)
            return "\"" + str.replace("\"", "\"\"").replace("\n", " ").replace("\r", " ") + "\""
        }
        fun safeLine(row: DiagnosticRow, utc: String): String {
            val cells = arrayOf<Any?>(utc,row.elapsedMs,row.session,row.event,row.targetSelected,
                row.serviceAdvertised,row.rawRssi,row.gpsEnabled,row.zone,row.gpsAccuracyMeters?.let{ "%.1f".format(Locale.US,it) },
                row.gpsAgeMs,row.parkedAgeMs,row.thresholdDbm,row.decision,row.reason,row.scannerHealthy,
                row.boundSeenAgeMs,"SIMULATED_FOR_SHADOW_ONLY",false,row.annotation)
            return cells.joinToString(",") { cell(it) }
        }
    }
    private var count = 0
    private var lastSessionId = 0
    private val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).also {
        it.timeZone = TimeZone.getTimeZone("UTC")
    }
    @Synchronized fun begin() {
        file.parentFile?.mkdirs()
        FileOutputStream(file, false).use { stream ->
            stream.write((HEADER+"\n").toByteArray(StandardCharsets.UTF_8))
        }
        count = 0
        lastSessionId = 0
    }
    /** Preserve an interrupted measurement after Activity recreation or process death. */
    @Synchronized fun resume(): Int {
        if (!file.exists() || file.length() == 0L) {
            begin()
            return 0
        }
        val firstLine = file.bufferedReader(StandardCharsets.UTF_8).use { it.readLine() }
        if (firstLine != HEADER) {
            // Never silently overwrite a file with an unknown CSV schema.
            throw IllegalStateException("Existing CSV schema changed; export or rename before using")
        }
        var seen = 0
        var highest = 0
        val matcher = Regex("^\"[^\"]*\",\"[^\"]*\",\"([0-9]+)\"")
        file.bufferedReader(StandardCharsets.UTF_8).useLines { rows ->
            rows.drop(1).forEach { line ->
                if (line.isNotEmpty()) {
                    seen++
                    val id = matcher.find(line)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
                    if (id > highest) highest = id
                }
            }
        }
        count = seen
        lastSessionId = highest
        return lastSessionId
    }
    @Synchronized fun add(row: DiagnosticRow): Boolean {
        if (count >= MAX_RECORDS) return false
        val line = safeLine(row, iso.format(Date())) + "\n"
        FileOutputStream(file, true).use { stream ->
            stream.write(line.toByteArray(StandardCharsets.UTF_8))
        }
        count++
        if (row.session > lastSessionId) lastSessionId = row.session
        return true
    }
    fun path(): File = file
    fun sizeRows(): Int = count
}
