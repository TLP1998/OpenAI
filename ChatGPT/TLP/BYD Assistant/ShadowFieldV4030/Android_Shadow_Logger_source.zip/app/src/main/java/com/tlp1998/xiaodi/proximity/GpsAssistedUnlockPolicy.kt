package com.tlp1998.xiaodi.proximity

import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * V4.0.30 candidate: raw-RSSI + optional coarse GPS automatic-unlock policy.
 * No platform API, networking, account, VIN, PIN, BLE MAC, or vehicle command is used here.
 *
 * Trust boundary: the Android caller verifies the user's selected BLE identity AND expected BYD
 * service, the authenticated BYD session, vehicle status, and command receipts. GPS and static
 * BLE addresses are NOT cryptographic proof of ownership or physical proximity.
 */
data class GeoPoint(val lat: Double, val lon: Double) {
    init { require(lat.isFinite() && lon.isFinite() && lat in -90.0..90.0 && lon in -180.0..180.0) }
}

/** elapsed timestamps must use Android SystemClock.elapsedRealtime() (ms), not wall clock. */
data class LocationEvidence(
    val point: GeoPoint,
    val horizontalAccuracyMeters: Double,
    val sampledElapsedMs: Long,
    val isMock: Boolean = false
)

data class ParkingEvidence(val point: GeoPoint, val savedElapsedMs: Long)

data class UnlockSettings(
    val normalUnlockRssi: Int = -74,         // V4.0.30 trial; V4.0.29 log showed -70
    val assistedUnlockRssi: Int = -79,       // only when opted-in GPS corroborates proximity region
    val lockRssi: Int = -95,                 // not modified by this unlock-only patch
    val gpsAssistEnabled: Boolean = false,  // location assist is off until the user enables it
    val gpsRadiusMeters: Double = 200.0,
    val gpsMaxAccuracyMeters: Double = 60.0,
    val gpsMaxAgeMs: Long = 30_000L,
    val parkingMaxAgeMs: Long = 48L * 60 * 60 * 1000,
    val minFarDwellMs: Long = 600L,
    val scanGapToArmMs: Long = 12_000L,
    val minIndependentNearGapMs: Long = 300L,
    val nearWindowMs: Long = 3_500L
) {
    init {
        require(lockRssi in -105..-45 && normalUnlockRssi in -95..-25 && assistedUnlockRssi in -95..-25)
        require(lockRssi < assistedUnlockRssi && assistedUnlockRssi <= normalUnlockRssi)
        require(gpsRadiusMeters in 60.0..1500.0 && gpsMaxAccuracyMeters in 5.0..300.0)
        require(gpsMaxAgeMs in 1_000L..120_000L && parkingMaxAgeMs > 0)
        require(minFarDwellMs in 100L..10_000L && scanGapToArmMs in 5_000L..120_000L)
        require(minIndependentNearGapMs in 100L..1_500L && nearWindowMs >= 2 * minIndependentNearGapMs)
    }
}

enum class LocationZone { CONFIDENT_INSIDE, CONFIDENT_OUTSIDE, UNKNOWN }
enum class UnlockDecision { NONE, REQUEST_UNLOCK }

data class UnlockInput(
    val nowElapsedMs: Long,
    val rawRssi: Int,
    val boundDeviceAndServiceVerified: Boolean,
    val automationEnabled: Boolean,
    val authenticatedCloudSession: Boolean,
    val controlBusy: Boolean,
    val vehicleKnownMoving: Boolean,
    val phoneKnownInsideVehicle: Boolean,
    val location: LocationEvidence?,
    val parking: ParkingEvidence?
)

/**
 * A caller-supplied healthy BLE scan heartbeat. `activeScanStartedElapsedMs` must be the time
 * at which the same scanning session began; scan suspension/permission loss MUST call onScanStopped.
 * Never infer absence from a stopped, throttled, or background-paused scanner.
 */
data class ScanGapInput(
    val nowElapsedMs: Long,
    val activeScanStartedElapsedMs: Long,
    val activeScanningVerified: Boolean,
    val boundIdentityConfigured: Boolean,
    val automationEnabled: Boolean
)

data class UnlockResult(
    val decision: UnlockDecision,
    val reason: String,
    val zone: LocationZone,
    val effectiveUnlockRssi: Int
)

class GpsAssistedUnlockPolicy(private val settings: UnlockSettings = UnlockSettings()) {
    private var armedByDeparture = false
    private var requestIssuedForApproach = false
    private var firstFarMs: Long? = null
    private var lastBoundSeenMs: Long? = null
    private var firstNearMs: Long? = null
    private var lastNearMs: Long? = null
    private var nearCount = 0
    private var lastClockMs: Long? = null

    fun reset() {
        armedByDeparture = false
        requestIssuedForApproach = false
        firstFarMs = null
        lastBoundSeenMs = null
        clearNear()
        lastClockMs = null
    }

    /** Do not keep stale absence/armed state across scan stops, service restarts or permission loss. */
    fun onScanStopped() = reset()

    /** A definite success receipt isn't a physical lock sensor; require a NEW departure again. */
    fun onLockCommandConfirmed() {
        armedByDeparture = false
        requestIssuedForApproach = false
        firstFarMs = null
        lastBoundSeenMs = null
        clearNear()
    }

    private fun clearNear() {
        nearCount = 0
        firstNearMs = null
        lastNearMs = null
    }

    private fun tick(now: Long): Boolean {
        if (now < 0 || lastClockMs?.let { now < it } == true) {
            reset()
            return false
        }
        lastClockMs = now
        return true
    }

    /**
     * REARM via a real gap, not just the absence of a callback at an arbitrary time.
     * Must have seen the bound device once in THIS continuous scan session.
     */
    fun observeActiveScanGap(input: ScanGapInput): Boolean {
        if (!input.automationEnabled || !input.activeScanningVerified ||
            !input.boundIdentityConfigured || !tick(input.nowElapsedMs)) {
            reset()
            return false
        }
        val lastSeen = lastBoundSeenMs ?: return false // a cold app start cannot arm automatically
        if (input.activeScanStartedElapsedMs < 0 ||
            input.activeScanStartedElapsedMs > lastSeen ||
            input.activeScanStartedElapsedMs > input.nowElapsedMs) return false
        if (input.nowElapsedMs - lastSeen < settings.scanGapToArmMs) return false
        if (requestIssuedForApproach) return false
        armedByDeparture = true
        clearNear()
        firstFarMs = null
        return true
    }

    fun observe(input: UnlockInput): UnlockResult {
        val zone = classifyLocation(input.nowElapsedMs, input.location, input.parking)
        val threshold = if (settings.gpsAssistEnabled && zone == LocationZone.CONFIDENT_INSIDE)
            settings.assistedUnlockRssi else settings.normalUnlockRssi
        fun result(reason: String, decision: UnlockDecision = UnlockDecision.NONE) =
            UnlockResult(decision, reason, zone, threshold)

        if (!input.automationEnabled) {
            reset()
            return result("DISABLED")
        }
        if (!tick(input.nowElapsedMs)) return result("CLOCK_RESET")
        if (!input.boundDeviceAndServiceVerified) {
            clearNear()
            firstFarMs = null
            // An unrelated BLE packet is NOT evidence of departure; do not clear last bound observation.
            return result("NOT_BOUND_DEVICE")
        }
        if (input.rawRssi !in -105..-15) {
            clearNear()
            return result("INVALID_RSSI")
        }
        // RSSI packet from a bound device is always tracked, but never itself proof of authorization.
        lastBoundSeenMs = input.nowElapsedMs
        if (!input.authenticatedCloudSession || input.controlBusy ||
            input.vehicleKnownMoving || input.phoneKnownInsideVehicle) {
            clearNear()
            firstFarMs = null
            return result("SAFETY_BLOCK")
        }
        if (settings.gpsAssistEnabled && zone == LocationZone.CONFIDENT_OUTSIDE) {
            clearNear()
            firstFarMs = null
            return result("GPS_CONFIDENT_OUTSIDE")
        }

        // No averaging, hysteresis filter, walking requirement or GPS-only trigger.
        if (input.rawRssi <= settings.lockRssi) {
            clearNear()
            if (firstFarMs == null) firstFarMs = input.nowElapsedMs
            if (!requestIssuedForApproach && input.nowElapsedMs - firstFarMs!! >= settings.minFarDwellMs)
                armedByDeparture = true
            return result(if (armedByDeparture) "FAR_ARMED" else "FAR_ARMING")
        }
        firstFarMs = null
        if (requestIssuedForApproach) return result("ONE_REQUEST_PER_APPROACH")
        if (!armedByDeparture) {
            clearNear()
            return result("WAIT_FOR_DEPARTURE")
        }
        if (input.rawRssi < threshold) {
            clearNear()
            return result("BELOW_UNLOCK_THRESHOLD")
        }
        if (firstNearMs == null || input.nowElapsedMs - firstNearMs!! > settings.nearWindowMs) {
            firstNearMs = input.nowElapsedMs
            lastNearMs = input.nowElapsedMs
            nearCount = 1
            return result("ONE_RAW_NEAR_SAMPLE")
        }
        if (lastNearMs != null && input.nowElapsedMs - lastNearMs!! < settings.minIndependentNearGapMs)
            return result("DUPLICATE_OR_TOO_CLOSE_SAMPLE")
        lastNearMs = input.nowElapsedMs
        nearCount++
        if (nearCount < 2) return result("ONE_RAW_NEAR_SAMPLE")
        requestIssuedForApproach = true
        armedByDeparture = false
        clearNear()
        return result("UNLOCK_REQUEST_ONCE", UnlockDecision.REQUEST_UNLOCK)
    }

    fun classifyLocation(nowElapsedMs: Long, current: LocationEvidence?, parking: ParkingEvidence?): LocationZone {
        if (!settings.gpsAssistEnabled || current == null || parking == null) return LocationZone.UNKNOWN
        val accuracy = current.horizontalAccuracyMeters
        if (current.isMock || !accuracy.isFinite() || accuracy <= 0.0 ||
            accuracy > settings.gpsMaxAccuracyMeters ||
            nowElapsedMs < current.sampledElapsedMs ||
            nowElapsedMs - current.sampledElapsedMs > settings.gpsMaxAgeMs ||
            nowElapsedMs < parking.savedElapsedMs ||
            nowElapsedMs - parking.savedElapsedMs > settings.parkingMaxAgeMs) return LocationZone.UNKNOWN
        val distance = metersBetween(current.point, parking.point)
        return when {
            distance + accuracy <= settings.gpsRadiusMeters -> LocationZone.CONFIDENT_INSIDE
            distance - accuracy > settings.gpsRadiusMeters -> LocationZone.CONFIDENT_OUTSIDE
            else -> LocationZone.UNKNOWN
        }
    }

    private fun metersBetween(a: GeoPoint, b: GeoPoint): Double {
        val lat1 = Math.toRadians(a.lat)
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2).pow(2) + cos(lat1) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
        return 2.0 * 6_371_000.0 * asin(min(1.0, sqrt(h)))
    }
}
