package com.tlp1998.xiaodi.proximity

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.os.SystemClock

/**
 * Android 15-compatible, OPTIONAL helper. This file is NOT compiled/tested without Android SDK.
 * Start only after explicit GPS opt-in, permissions and foreground-service restrictions are met.
 * Never log latitude/longitude. Never persist phone GPS trails.
 */
class AndroidGpsEvidenceProvider(private val context: Context) {
    private val manager by lazy { context.getSystemService(LocationManager::class.java) }
    @Volatile private var lastFix: LocationEvidence? = null
    private var started = false
    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            if (!location.hasAccuracy()) return
            val mocked = if (Build.VERSION.SDK_INT >= 31) location.isMock
                else @Suppress("DEPRECATION") location.isFromMockProvider
            val sampleMs = location.elapsedRealtimeNanos / 1_000_000L
            val converted = try {
                LocationEvidence(
                    point = GeoPoint(location.latitude, location.longitude),
                    horizontalAccuracyMeters = location.accuracy.toDouble(),
                    sampledElapsedMs = sampleMs,
                    isMock = mocked
                )
            } catch (_: IllegalArgumentException) { return }
            // A lower-quality/older callback must not replace a fresher fix.
            val previous = lastFix
            if (previous == null || converted.sampledElapsedMs >= previous.sampledElapsedMs) {
                lastFix = converted
            }
        }
        @Suppress("DEPRECATION")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
        override fun onProviderEnabled(provider: String) = Unit
        override fun onProviderDisabled(provider: String) = Unit
    }

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (started) return true
        if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) !=
            PackageManager.PERMISSION_GRANTED) return false
        try {
            if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3_000L, 0f,
                    listener, Looper.getMainLooper())
                started = true
            }
            if (manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5_000L, 0f,
                    listener, Looper.getMainLooper())
                started = true
            }
        } catch (_: SecurityException) {
            stop()
            return false
        } catch (_: IllegalArgumentException) {
            stop()
            return false
        }
        return started
    }

    fun latest(): LocationEvidence? {
        val f = lastFix ?: return null
        // Hard expiration here too; decision kernel will apply the configurable accuracy check.
        return if (SystemClock.elapsedRealtime() - f.sampledElapsedMs in 0..30_000L) f else null
    }

    fun stop() {
        try { manager.removeUpdates(listener) } catch (_: SecurityException) { }
        started = false
        lastFix = null
    }
}
