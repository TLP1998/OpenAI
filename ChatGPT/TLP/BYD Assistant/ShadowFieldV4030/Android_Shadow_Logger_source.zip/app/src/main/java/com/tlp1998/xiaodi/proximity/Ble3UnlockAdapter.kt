package com.tlp1998.xiaodi.proximity

/**
 * BLE3 service integration boundary. Kotlin/JVM and Android compatible; no BYD network code.
 * Keep old RSSI auto-LOCK path separate: this adapter proposes only UNLOCK.
 *
 * The service must verify the bound BLE hardware identity and expected BYD service UUID BEFORE
 * invoking onBoundAdvertisement. The mobile phone/GPS cannot authenticate a car by themselves.
 */
enum class UnlockMode { SHADOW, LIVE }
enum class UnlockEffect { NO_ACTION, SHADOW_WOULD_UNLOCK, UNLOCK_ENQUEUED, UNLOCK_DISPATCH_FAILED }

data class Ble3SafetyContext(
    val automationEnabled: Boolean,
    val deviceAddressAndBydServiceVerified: Boolean,
    val vehicleBindingVerified: Boolean,
    /** Explicit fresh vehicle-side or otherwise independently verified parked/stopped state. */
    val freshVehicleStoppedEvidence: Boolean,
    val authenticatedCloudSession: Boolean,
    val controlBusy: Boolean,
    val vehicleKnownMoving: Boolean,
    val phoneKnownInsideVehicle: Boolean,
    val location: LocationEvidence?,
    val parking: ParkingEvidence?
)

data class AdapterOutcome(val effect: UnlockEffect, val policy: UnlockResult)

class Ble3UnlockAdapter(
    initialSettings: UnlockSettings,
    private val mode: () -> UnlockMode = { UnlockMode.SHADOW },
    private val enqueueUnlockRequest: () -> Boolean = { false },
    private val auditReasonOnly: (String) -> Unit = {}
) {
    private var settings = initialSettings
    private var policy = GpsAssistedUnlockPolicy(settings)
    private var scanStartedMs: Long? = null

    /** Invoke on a new BLE scan session, including after permission recovery. */
    @Synchronized fun onScannerStarted(nowElapsedMs: Long) {
        policy.onScanStopped()
        scanStartedMs = if (nowElapsedMs >= 0) nowElapsedMs else null
        auditReasonOnly("BLE_SCAN_STARTED")
    }

    /** Call on scanner pause, stop, permission loss, service recreation, or BT off. */
    @Synchronized fun onScannerStopped() {
        scanStartedMs = null
        policy.onScanStopped()
        auditReasonOnly("BLE_SCAN_STOPPED")
    }

    /** Threshold/feature changes must not carry over an armed state from the old settings. */
    @Synchronized fun applySettings(updated: UnlockSettings) {
        if (updated != settings) {
            settings = updated
            policy = GpsAssistedUnlockPolicy(updated)
            auditReasonOnly("POLICY_SETTINGS_RESET")
        }
    }

    /** Heartbeat ONLY if scanning has been continuously active (not merely a 1-second timer). */
    @Synchronized fun onHealthyScannerHeartbeat(
        nowElapsedMs: Long,
        actualScanActive: Boolean,
        boundDeviceConfigured: Boolean,
        automationEnabled: Boolean
    ): Boolean {
        val begin = scanStartedMs ?: return false
        if (!actualScanActive) {
            onScannerStopped()
            return false
        }
        val armed = policy.observeActiveScanGap(
            ScanGapInput(nowElapsedMs, begin, true, boundDeviceConfigured, automationEnabled)
        )
        if (armed) auditReasonOnly("DEPARTURE_CONFIRMED_BY_BLE_SCAN_GAP")
        return armed
    }

    /**
     * The policy marks its one-shot decision before enqueueUnlockRequest is called.
     * A network failure will NOT cause automatic retry during the same approach.
     * The callback must only enqueue a request; validate the real BYD control receipt separately.
     */
    @Synchronized fun onBoundAdvertisement(nowElapsedMs: Long, rawRssi: Int, safety: Ble3SafetyContext): AdapterOutcome {
        if (scanStartedMs == null) {
            val blocked = UnlockResult(UnlockDecision.NONE, "SCANNER_NOT_ACTIVE", LocationZone.UNKNOWN,
                settings.normalUnlockRssi)
            return AdapterOutcome(UnlockEffect.NO_ACTION, blocked)
        }
        val input = UnlockInput(
            nowElapsedMs = nowElapsedMs,
            rawRssi = rawRssi,
            boundDeviceAndServiceVerified = safety.deviceAddressAndBydServiceVerified && safety.vehicleBindingVerified,
            automationEnabled = safety.automationEnabled,
            authenticatedCloudSession = safety.authenticatedCloudSession && safety.freshVehicleStoppedEvidence,
            controlBusy = safety.controlBusy,
            vehicleKnownMoving = safety.vehicleKnownMoving,
            phoneKnownInsideVehicle = safety.phoneKnownInsideVehicle,
            location = safety.location,
            parking = safety.parking
        )
        val result = policy.observe(input)
        auditReasonOnly(result.reason) // Never include phone/vehicle coordinates or BLE MAC addresses.
        if (result.decision != UnlockDecision.REQUEST_UNLOCK) return AdapterOutcome(UnlockEffect.NO_ACTION, result)
        if (mode() != UnlockMode.LIVE) return AdapterOutcome(UnlockEffect.SHADOW_WOULD_UNLOCK, result)
        val accepted = try { enqueueUnlockRequest() } catch (_: Exception) { false }
        return AdapterOutcome(if (accepted) UnlockEffect.UNLOCK_ENQUEUED else UnlockEffect.UNLOCK_DISPATCH_FAILED, result)
    }

    /** Only call on an actual successful lock-command receipt, NOT an HTTP ACK or request accept. */
    @Synchronized fun onConfirmedLockSuccess() {
        policy.onLockCommandConfirmed()
        auditReasonOnly("LOCK_COMMAND_CONFIRMED_RESET")
    }
}
