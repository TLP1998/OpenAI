package com.tlp1998.xiaodi.shadowprobe

/**
 * Present raw (unfiltered) target RSSI without confusing old BLE samples with live radio data.
 * Pure Kotlin so the state logic can be JVM-tested without Android or vehicle access.
 */
internal class LiveRssiState(
    private val liveMaxAgeMs: Long = 2_500L,
    private val delayedMaxAgeMs: Long = 5_000L
) {
    enum class Phase { NOT_SELECTED, SCAN_STOPPED, WAITING, LIVE, DELAYED, STALE }
    data class Snapshot(val phase: Phase, val value: Int?, val ageMs: Long?, val description: String)
    private var lastValue: Int? = null
    private var lastSampleTimeMs: Long = -1L

    fun resetTarget() {
        lastValue = null
        lastSampleTimeMs = -1L
    }

    fun onTargetPacket(rawRssiDbm: Int, receivedElapsedMs: Long) {
        require(rawRssiDbm in -127..20) { "RSSI out of plausible radio range" }
        require(receivedElapsedMs >= 0) { "Negative monotonic timestamp" }
        lastValue = rawRssiDbm
        lastSampleTimeMs = receivedElapsedMs
    }

    fun snapshot(nowElapsedMs: Long, scanning: Boolean, targetSelected: Boolean): Snapshot {
        if (!targetSelected) return Snapshot(Phase.NOT_SELECTED, null, null,
            "目标 RSSI：— dBm（先在列表中选择车辆广播）")
        val age = lastSampleTimeMs.takeIf { it >= 0L }
            ?.let { (nowElapsedMs - it).takeIf { diff -> diff >= 0L } }
        if (!scanning) return Snapshot(Phase.SCAN_STOPPED, lastValue, age,
            "目标 RSSI：— dBm（扫描已停止；上次 ${lastValue?.let { "$it dBm" } ?: "无数据"}）")
        if (lastValue == null || age == null) return Snapshot(Phase.WAITING, null, null,
            "目标 RSSI：— dBm（正在等待已选目标广播）")
        val seconds = "%.1f".format(java.util.Locale.US, age / 1000.0)
        return when {
            age <= liveMaxAgeMs -> Snapshot(Phase.LIVE, lastValue, age,
                "目标 RSSI：$lastValue dBm  ·  实时  ${seconds}s前")
            age <= delayedMaxAgeMs -> Snapshot(Phase.DELAYED, lastValue, age,
                "目标 RSSI：$lastValue dBm  ·  延迟  ${seconds}s前")
            else -> Snapshot(Phase.STALE, lastValue, age,
                "目标 RSSI：— dBm（信号已过期，上次 $lastValue dBm，${seconds}s前）")
        }
    }
}
