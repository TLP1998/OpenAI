package com.tlp1998.xiaodi.shadowprobe

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.ParcelUuid
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.tlp1998.xiaodi.proximity.AndroidGpsEvidenceProvider
import com.tlp1998.xiaodi.proximity.GpsAssistedUnlockPolicy
import com.tlp1998.xiaodi.proximity.ParkingEvidence
import com.tlp1998.xiaodi.proximity.ScanGapInput
import com.tlp1998.xiaodi.proximity.UnlockDecision
import com.tlp1998.xiaodi.proximity.UnlockInput
import com.tlp1998.xiaodi.proximity.UnlockSettings
import java.io.File
import java.io.IOException
import java.util.UUID

/**
 * Standalone Android field probe. NEVER controls a vehicle, connects to BYD cloud,
 * attempts GATT pairing, or requests Internet permission. The policy gates that
 * would normally require authenticated cloud/vehicle status are SIMULATED ONLY.
 * The CSV explicitly records this fact on EVERY row.
 */
class ShadowActivity : Activity() {
    private data class Seen(val address: String, val name: String, val rssi: Int)

    private val handler = Handler(Looper.getMainLooper())
    private val devices = mutableListOf<Seen>()
    private lateinit var deviceListAdapter: ArrayAdapter<String>
    private lateinit var status: TextView
    private lateinit var progress: TextView
    private lateinit var liveRssi: TextView
    private val liveState = LiveRssiState()
    private var lastLiveUiAtMs = 0L
    private var lastLoggedLivePhase: LiveRssiState.Phase? = null
    private lateinit var uuidInput: EditText
    private lateinit var gpsOption: CheckBox
    private lateinit var recorder: DiagnosticCsvRecorder
    private lateinit var gps: AndroidGpsEvidenceProvider
    private var policy = GpsAssistedUnlockPolicy()
    private var selectedAddress: String? = null // memory only, NEVER written to diagnostic CSV
    private var parking: ParkingEvidence? = null // memory only, GPS coordinates NEVER exported
    private var scanning = false
    private var scanStartedMs = 0L
    private var lastAnyPacketMs = 0L
    private var lastBoundSampleMs = 0L
    private var lastHeartbeatMs = 0L
    private var healthyLastTick = false
    private var session = 0
    private var rawPackets = 0
    private var shadowCandidates = 0
    private var lastDisplayed = 0L
    private var callback: ScanCallback? = null
    private var exportInProgress = false
    private var exportedSuccessfully = false
    private val gapTicker = object : Runnable {
        override fun run() {
            if (!scanning) return
            val now = SystemClock.elapsedRealtime()
            val healthy = lastAnyPacketMs > 0L && now - lastAnyPacketMs <= 4000L
            if (healthy && !healthyLastTick) {
                record("SCAN_HEALTH_RECOVERED", null, false, "RECENT_ADVERTISEMENT_CALLBACKS", true)
            }
            if (!healthy && healthyLastTick) {
                // Android can pause/throttle scans. Do not infer a physical departure from silence.
                policy.onScanStopped()
                scanStartedMs = now
                record("SCAN_UNHEALTHY_RESET", null, false, "SCAN_NOT_PROVEN_ACTIVE", false)
            }
            healthyLastTick = healthy
            if (healthy && selectedAddress != null) {
                val rearmed = policy.observeActiveScanGap(ScanGapInput(
                    nowElapsedMs = now,
                    activeScanStartedElapsedMs = scanStartedMs,
                    activeScanningVerified = true,
                    boundIdentityConfigured = true,
                    automationEnabled = true
                ))
                if (rearmed) record("DEPARTURE_ARMED", null, false,
                    "BOUND_DEVICE_MISSING_WHILE_OTHER_ADVERTISEMENTS_VISIBLE", true)
            } else if (now - lastHeartbeatMs >= 5000L) {
                lastHeartbeatMs = now
                record("HEARTBEAT", null, false,
                    if (healthy) "WAIT_FOR_TARGET_BINDING" else "SCAN_NOT_VERIFIABLY_HEALTHY", healthy)
            }
            refreshStatus()
            val phase = liveState.snapshot(now, scanning, selectedAddress != null).phase
            if (lastLoggedLivePhase != phase) {
                lastLoggedLivePhase = phase
                record("RSSI_UI_STATE", null, false, phase.name, healthy)
            }
            handler.postDelayed(this, 1000L)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun vertical(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(12), dp(16), dp(20))
    }
    private fun label(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        setPadding(0, dp(6), 0, dp(6))
    }
    private fun addButton(layout: LinearLayout, text: String, action: () -> Unit) {
        layout.addView(Button(this).apply {
            this.text = text
            setOnClickListener { action() }
        })
    }
    private fun note(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        gps = AndroidGpsEvidenceProvider(this)
        recorder = DiagnosticCsvRecorder(File(filesDir, "byd-shadow-field.csv"))
        session = try { recorder.resume() } catch (_: IllegalStateException) {
            // Preserve old unknown-format diagnostics rather than overwrite them.
            recorder = DiagnosticCsvRecorder(File(filesDir,
                "byd-shadow-field-new-${System.currentTimeMillis()}.csv"))
            recorder.begin()
            0
        }
        val page = vertical()
        page.addView(label("小迪 V4.0.30 · BLE/GPS 实车影子验收\n只扫描、只记录，不联网、不解锁、不锁车。此独立 App 不覆盖小迪车控助手。"))
        status = label("待开始扫描")
        page.addView(status)
        liveRssi = label("目标 RSSI：— dBm（等待扫描）").apply {
            textSize = 25f
            setPadding(0, dp(12), 0, dp(12))
        }
        page.addView(liveRssi)
        page.addView(label("实时数值取自已选目标的原始广播，不做滤波。数值延迟或扫描停止时会标明，不将旧值冒充实时值。"))
        page.addView(label("① 开始扫描后，点选你确认的车辆 BLE 广播（仅本次内存绑定）。"))
        deviceListAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        val deviceList = ListView(this).apply { adapter = deviceListAdapter }
        page.addView(deviceList, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)))
        deviceList.setOnItemClickListener { _, _, position, _ ->
            if (position !in devices.indices) return@setOnItemClickListener
            val target = devices[position]
            AlertDialog.Builder(this)
                .setTitle("选择 BLE 设备")
                .setMessage("名称：${target.name}\n尾号：${target.address.takeLast(5)}\n\n仅用于本次影子测量；不能证明车辆身份，不会执行车控。")
                .setPositiveButton("确认") { _, _ ->
                    selectedAddress = target.address
                    liveState.resetTarget()
                    lastLoggedLivePhase = null
                    policy.reset()
                    scanStartedMs = SystemClock.elapsedRealtime()
                    record("TARGET_SELECTED", null, false, "RADIO_ONLY_TARGET", healthyLastTick)
                    refreshStatus()
                }
                .setNegativeButton("取消", null).show()
        }
        uuidInput = EditText(this).apply {
            hint = "可选：已知 BYD 广播服务 UUID（未知请留空）"
            setSingleLine(true)
            textSize = 13f
        }
        page.addView(uuidInput)
        gpsOption = CheckBox(this).apply {
            text = "启用 GPS 辅助影子判断（自愿；不上传坐标）"
            isChecked = false
            setOnCheckedChangeListener { _, enabled ->
                policy = GpsAssistedUnlockPolicy(UnlockSettings(gpsAssistEnabled = enabled))
                scanStartedMs = SystemClock.elapsedRealtime()
                if (enabled) {
                    if (hasLocationPermission()) gps.start()
                    else requestNeededPermissions()
                } else gps.stop()
                record("GPS_OPTION_CHANGED", null, false,
                    if (enabled) "GPS_OPT_IN" else "GPS_OPT_OUT", healthyLastTick)
            }
        }
        page.addView(gpsOption)
        addButton(page, "② 记录当前位置为停车点（需 GPS 定位）") {
            if (!gpsOption.isChecked || !hasLocationPermission()) {
                note("请先打开 GPS 辅助并授权精确定位")
                return@addButton
            }
            gps.start()
            val fix = gps.latest()
            if (fix == null || fix.isMock || fix.horizontalAccuracyMeters > 60.0) {
                note("未取得有效且精度≤60米的非模拟定位，请稍后再试")
                record("PARKING_POINT_REJECTED", null, false, "GPS_NOT_QUALIFIED", healthyLastTick)
            } else {
                parking = ParkingEvidence(fix.point, SystemClock.elapsedRealtime())
                note("停车点已保存在本次会话内存中（不导出经纬度）")
                record("PARKING_POINT_SET", null, false, "GPS_MEMORY_ONLY", healthyLastTick)
            }
            refreshStatus()
        }
        addButton(page, "开始扫描 / 重新开始") { startScan() }
        addButton(page, "场景打点（离车、返回、靠近车门等）") { pickMarker() }
        addButton(page, "停止扫描") { stopScan("USER_STOP") }
        addButton(page, "③ 导出 CSV 诊断日志") { exportCsv() }
        addButton(page, "确认导出后新建一份空白日志") {
            if (!exportedSuccessfully) {
                note("先导出并保存本次 CSV，避免误删采样记录")
            } else {
                AlertDialog.Builder(this).setTitle("清空旧日志？")
                    .setMessage("确认你已经保存好导出的 CSV。这会开始新的日志记录。")
                    .setNegativeButton("取消",null)
                    .setPositiveButton("新建") { _, _ ->
                        stopScan("NEW_LOG")
                        recorder.begin()
                        session = 0
                        exportedSuccessfully = false
                        rawPackets = 0
                        shadowCandidates = 0
                        refreshStatus()
                    }.show()
            }
        }
        progress = label("日志：0 条；原始 RSSI：0 条；影子候选：0 次")
        page.addView(progress)
        page.addView(label("测试提醒：先在车旁点选已知设备，然后离开再返回。手机保持屏幕亮起及 App 前台，扫描状态不可靠时不会以 BLE 消失作为离车证明。GPS 和 BLE 都不能单独证明解锁安全。"))
        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun requestNeededPermissions() {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                list.add(Manifest.permission.BLUETOOTH_SCAN)
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                list.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (!hasLocationPermission()) {
            list.add(Manifest.permission.ACCESS_COARSE_LOCATION)
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (list.isNotEmpty()) requestPermissions(list.toTypedArray(), 15)
    }
    private fun hasLocationPermission() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    private fun hasBluetoothPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 || (
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)

    @Suppress("MissingPermission")
    private fun startScan() {
        if (!hasBluetoothPermission() || !hasLocationPermission()) {
            requestNeededPermissions()
            note("授权完成后，请再按一次『开始扫描』")
            return
        }
        stopScan("RESTART", logEvent = false)
        val manager = getSystemService(BluetoothManager::class.java)
        val adapter = manager.adapter
        if (adapter == null || !adapter.isEnabled) {
            note("请打开手机蓝牙")
            return
        }
        val scanner = adapter.bluetoothLeScanner ?: run { note("BLE 扫描不可用"); return }
        devices.clear()
        deviceListAdapter.clear()
        session++
        rawPackets = 0
        shadowCandidates = 0
        liveState.resetTarget()
        lastLoggedLivePhase = null
        lastLiveUiAtMs = 0L
        lastAnyPacketMs = 0
        lastBoundSampleMs = 0
        healthyLastTick = false
        policy = GpsAssistedUnlockPolicy(UnlockSettings(gpsAssistEnabled = gpsOption.isChecked))
        scanStartedMs = SystemClock.elapsedRealtime()
        lastHeartbeatMs = scanStartedMs
        callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                runOnUiThread { onAdvertisement(result) }
            }
            override fun onBatchScanResults(results: MutableList<ScanResult>) {
                runOnUiThread { results.forEach { onAdvertisement(it) } }
            }
            override fun onScanFailed(errorCode: Int) {
                runOnUiThread {
                    record("SCAN_FAILED", null, false, "ANDROID_SCAN_ERROR_$errorCode", false)
                    stopScan("SCAN_FAILED")
                }
            }
        }
        try {
            scanner.startScan(null, ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), callback)
            scanning = true
            if (gpsOption.isChecked) gps.start()
            record("SCAN_STARTED", null, false, "SCREEN_ON_FOREGROUND_ONLY", false)
            handler.post(gapTicker)
            refreshStatus()
        } catch (error: Exception) {
            scanning = false
            callback = null
            record("SCAN_START_FAILED", null, false, error.javaClass.simpleName, false)
            note("启动扫描失败：${error.javaClass.simpleName}")
        }
    }

    @Suppress("MissingPermission")
    private fun onAdvertisement(result: ScanResult) {
        if (!scanning) return
        val now = SystemClock.elapsedRealtime()
        lastAnyPacketMs = now
        val address = result.device?.address ?: return
        val name = try { result.scanRecord?.deviceName ?: result.device?.name ?: "未知设备" }
                   catch (_: SecurityException) { result.scanRecord?.deviceName ?: "未知设备" }
        if (devices.size < 120) {
            val i = devices.indexOfFirst { it.address == address }
            val item = Seen(address, name.take(32), result.rssi)
            if (i >= 0) devices[i] = item else devices.add(item)
            if (now - lastDisplayed >= 1200L) {
                val shown = devices.sortedByDescending { it.rssi }.take(35)
                // Keep visible list mapping consistent with click indices.
                devices.clear(); devices.addAll(shown)
                deviceListAdapter.clear()
                deviceListAdapter.addAll(devices.map { "${it.name} · ${it.address.takeLast(5)} · ${it.rssi} dBm" })
                deviceListAdapter.notifyDataSetChanged()
                lastDisplayed = now
            }
        }
        if (address != selectedAddress) return
        rawPackets++
        lastBoundSampleMs = now
        liveState.onTargetPacket(result.rssi, now)
        // Each raw sample is logged; the visible number is throttled only to avoid UI overload.
        if (now - lastLiveUiAtMs >= 200L) {
            lastLiveUiAtMs = now
            refreshLiveRssi(now)
        }
        val expectedUuid = uuidInput.text.toString().trim()
        val advertised = if (expectedUuid.isEmpty()) false else try {
            val expected = ParcelUuid(UUID.fromString(expectedUuid))
            result.scanRecord?.serviceUuids?.contains(expected) == true
        } catch (_: IllegalArgumentException) { false }
        val fix = if (gpsOption.isChecked) gps.latest() else null
        // Explicit SHADOW SIMULATION: these are not actual cloud/vehicle states.
        // No network permission, no command interface and no LIVE mode exist in this app.
        val outcome = policy.observe(UnlockInput(
            nowElapsedMs = now,
            rawRssi = result.rssi,
            boundDeviceAndServiceVerified = true, // MANUALLY SELECTED radio identity only (not secure validation)
            automationEnabled = true,
            authenticatedCloudSession = true,   // SIMULATED, not queried!
            controlBusy = false,                 // SIMULATED, not queried!
            vehicleKnownMoving = false,         // SIMULATED, not queried!
            phoneKnownInsideVehicle = false,    // SIMULATED, not queried!
            location = fix, parking = parking
        ))
        if (outcome.decision == UnlockDecision.REQUEST_UNLOCK) shadowCandidates++
        record(
            event = if (outcome.decision == UnlockDecision.REQUEST_UNLOCK) "SHADOW_CANDIDATE" else "RSSI_SAMPLE",
            rawRssi = result.rssi, service = advertised, reason = outcome.reason,
            healthy = healthyLastTick,
            zone = outcome.zone.name,
            threshold = outcome.effectiveUnlockRssi
        )
        if (outcome.decision == UnlockDecision.REQUEST_UNLOCK) {
            note("影子候选：按模拟安全条件会请求解锁，但本 App 不会发送车控指令")
        }
        if (rawPackets % 8 == 0 || outcome.decision == UnlockDecision.REQUEST_UNLOCK) refreshStatus()
    }

    private fun pickMarker() {
        val options = arrayOf("车旁静止", "开始离车", "离车约10米", "离车约30米", "开始返回", "接近车门", "人在车内", "误解锁风险", "信号异常", "测试结束")
        AlertDialog.Builder(this).setTitle("记录测试场景")
            .setItems(options) { _, which ->
                record("SCENE_MARK", null, false, "MANUAL_SCENE_MARK", healthyLastTick, annotation=options[which])
                note("已记录：${options[which]}")
            }.show()
    }

    private fun record(event: String, rawRssi: Int?, service: Boolean, reason: String, healthy: Boolean,
                       zone: String? = null, threshold: Int? = null, annotation: String = "") {
        val now = SystemClock.elapsedRealtime()
        val fix = if (gpsOption.isChecked) gps.latest() else null
        val locZone = zone ?: if (gpsOption.isChecked) policy.classifyLocation(now, fix, parking).name else "DISABLED"
        val gpsAge = fix?.let { (now - it.sampledElapsedMs).takeIf { age -> age >= 0 } }
        val ageParked = parking?.let { (now - it.savedElapsedMs).takeIf { age -> age >= 0 } }
        try {
            val recorded = recorder.add(DiagnosticRow(
                elapsedMs=now, session=session, event=event,
                targetSelected=selectedAddress != null, serviceAdvertised=service, rawRssi=rawRssi,
                gpsEnabled=gpsOption.isChecked, zone=locZone,
                gpsAccuracyMeters=fix?.horizontalAccuracyMeters,
                gpsAgeMs=gpsAge, parkedAgeMs=ageParked,
                thresholdDbm=threshold, decision=if(event=="SHADOW_CANDIDATE") "SHADOW_ONLY" else "NONE",
                reason=reason, scannerHealthy=healthy,
                boundSeenAgeMs=lastBoundSampleMs.takeIf{ it>0L }?.let{ (now-it).coerceAtLeast(0L) },
                annotation=annotation
            ))
            if (recorded) exportedSuccessfully = false
            else status.text = "日志上限 30000 条，请停止并导出（不会覆盖既有数据）"
        } catch (e: IOException) {
            status.text = "写日志失败：${e.javaClass.simpleName}，请停止测试"
        }
    }

    private fun refreshLiveRssi(now: Long = SystemClock.elapsedRealtime()) {
        if (!::liveRssi.isInitialized) return
        liveRssi.text = liveState.snapshot(now, scanning, selectedAddress != null).description
    }

    private fun refreshStatus() {
        refreshLiveRssi()
        val target = if (selectedAddress == null) "未选设备" else "已选本次目标（尾号 ${selectedAddress?.takeLast(5)}，日志不保存）"
        status.text = "扫描：${if(scanning) "运行中" else "已停止"}；${target}\nGPS：${if(gpsOption.isChecked) "已开启" else "关闭"}；停车参考点：${if(parking==null) "未记录" else "已记录"}\n扫描健康：${if(healthyLastTick) "近期有 BLE 广播" else "未证实"}"
        progress.text = "日志 ${recorder.sizeRows()} 条；目标原始 RSSI $rawPackets 条；影子候选 $shadowCandidates 次\n全部命令发送次数：0（固定禁用）"
    }

    @Suppress("MissingPermission")
    private fun stopScan(reason: String, logEvent: Boolean = true) {
        handler.removeCallbacks(gapTicker)
        val local = callback
        if (local != null) {
            try { getSystemService(BluetoothManager::class.java).adapter?.bluetoothLeScanner?.stopScan(local) }
            catch (_: Exception) { }
        }
        callback = null
        val previously = scanning
        scanning = false
        healthyLastTick = false
        policy.onScanStopped()
        gps.stop()
        if (previously && logEvent) record("SCAN_STOPPED",null,false,reason,false)
        if (previously) {
            lastLoggedLivePhase = LiveRssiState.Phase.SCAN_STOPPED
            record("RSSI_UI_STATE",null,false,"SCAN_STOPPED_$reason",false)
        }
        if (::status.isInitialized) refreshStatus()
    }

    private fun exportCsv() {
        if (!recorder.path().exists()) { note("没有日志可导出"); return }
        if (scanning) stopScan("EXPORT")
        exportInProgress = true
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "xiaodi-shadow-v4030-${System.currentTimeMillis()}.csv")
        }
        startActivityForResult(intent, 119)
    }
    @Deprecated("Activity result API for dependency-free app")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        exportInProgress = false
        if (requestCode != 119 || resultCode != RESULT_OK || data?.data == null) return
        try {
            contentResolver.openOutputStream(data.data!!)?.use { out ->
                recorder.path().inputStream().use { input -> input.copyTo(out) }
            } ?: throw IOException("No output stream")
            exportedSuccessfully = true
            note("CSV 已导出；可发送给 ChatGPT 分析")
        } catch (e: Exception) { note("导出失败：${e.javaClass.simpleName}") }
    }
    override fun onPause() {
        super.onPause()
        // Important: App background / screen off is NOT proof of healthy BLE scanning.
        if (scanning && !exportInProgress) stopScan("ACTIVITY_NOT_FOREGROUND")
    }
    override fun onDestroy() {
        stopScan("ACTIVITY_DESTROYED")
        super.onDestroy()
    }
}
